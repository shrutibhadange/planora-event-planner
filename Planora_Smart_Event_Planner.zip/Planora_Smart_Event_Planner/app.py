from flask import Flask, render_template, request, jsonify
import sqlite3, json, os
from datetime import datetime

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "database", "planora.db")
app = Flask(__name__)

EVENTS = {
    "Birthday Party": {
        "shares": {"Food & catering": 0.32, "Decoration": 0.20, "Music & sound": 0.10, "Photographer": 0.08, "Video editor": 0.07, "Venue & seating": 0.15, "Cake & return gifts": 0.08},
        "materials": [
            ("Backdrop", "Pastel cloth or shimmer panel, backdrop stand, birthday banner"),
            ("Balloons", "Balloon arch kit, balloon pump, glue dots, ribbon"),
            ("Tables", "Cake table cloth, cake stand, themed tableware"),
            ("Lighting", "Warm fairy lights or LED string lights"),
            ("Finishing", "Welcome board, paper props, reusable centerpieces")
        ],
        "menu": ["Welcome drink: lemonade / fruit punch", "Snacks: mini sandwiches, samosa, fries", "Main: paneer curry, seasonal veg, naan / roti", "Rice: jeera rice", "Dessert: birthday cake, ice cream"]
    },
    "Wedding": {
        "shares": {"Food & catering": 0.35, "Decoration": 0.18, "Music & sound": 0.08, "Photographer": 0.09, "Video editor": 0.08, "Venue & seating": 0.17, "Makeup & misc.": 0.05},
        "materials": [
            ("Mandap / stage", "Mandap frame, drapes, stage platform, seating"),
            ("Flowers", "Marigold / rose garlands, floral strings, foliage"),
            ("Lighting", "Warm LEDs, spotlights, extension boards"),
            ("Guest area", "Chair covers, table cloths, welcome signage"),
            ("Ceremony items", "Aisle decor, entry sign, ceremony-specific items")
        ],
        "menu": ["Welcome drinks: mocktail / lemonade", "Starters: paneer tikka, veg kebabs", "Main: paneer curry, seasonal veg, dal", "Rice & breads: pulao, naan / roti", "Sides: salad, raita, papad", "Dessert: gulab jamun / ice cream"]
    },
    "Haldi Ceremony": {
        "shares": {"Food & catering": 0.30, "Decoration": 0.24, "Music & sound": 0.10, "Photographer": 0.09, "Video editor": 0.06, "Venue & seating": 0.13, "Haldi supplies & misc.": 0.08},
        "materials": [
            ("Haldi backdrop", "Yellow / orange fabric, backdrop stand, marigold strings"),
            ("Floral decor", "Marigold garlands, loose petals, flower baskets"),
            ("Seating", "Low wooden stool / chowki, washable cloth, cushions"),
            ("Haldi setup", "Haldi bowls, trays, spoons, towels, water bowls"),
            ("Guest comfort", "Floor mats, disposable / washable covers, drinking water")
        ],
        "menu": ["Welcome: nimbu pani / jaljeera", "Snacks: kachori, dhokla, mini samosa", "Main: puri, aloo sabzi, pulao", "Sides: salad, chutney, papad", "Dessert: jalebi / shrikhand"]
    },
    "Engagement": {
        "shares": {"Food & catering": 0.32, "Decoration": 0.20, "Music & sound": 0.09, "Photographer": 0.10, "Video editor": 0.08, "Venue & seating": 0.16, "Misc.": 0.05},
        "materials": [
            ("Stage", "Backdrop frame, elegant drapes, couple seating"),
            ("Flowers", "Rose / seasonal flowers, floral arrangements"),
            ("Lighting", "Warm LED lights, spotlights"),
            ("Tables", "Guest tables, runners, centerpieces"),
            ("Welcome", "Entry sign, photo corner props")
        ],
        "menu": ["Welcome drinks: mocktails", "Starters: paneer tikka, kebabs", "Main: paneer curry, dal, seasonal veg", "Rice & breads: pulao, naan / roti", "Dessert: gulab jamun / mousse"]
    },
    "Corporate Event": {
        "shares": {"Food & catering": 0.25, "Decoration & branding": 0.10, "Audio / visual": 0.15, "Photographer": 0.06, "Video editor": 0.06, "Venue & seating": 0.28, "Printing & misc.": 0.10},
        "materials": [
            ("Stage & branding", "Podium, branded backdrop, logo board"),
            ("Audio / visual", "Microphones, speakers, projector / screen"),
            ("Seating", "Conference chairs, tables, table signage"),
            ("Registration", "Check-in desk, name badges, printed agenda"),
            ("Lighting", "Stage lights, safe cable covers")
        ],
        "menu": ["Welcome tea / coffee", "Snacks: sandwiches, biscuits, fruit", "Lunch: veg / non-veg options as required", "Drinks: water, tea, coffee", "Dessert: brownie / fruit"]
    },
    "Baby Shower": {
        "shares": {"Food & catering": 0.32, "Decoration": 0.22, "Music & sound": 0.06, "Photographer": 0.10, "Video editor": 0.06, "Venue & seating": 0.16, "Gifts & misc.": 0.08},
        "materials": [
            ("Backdrop", "Pastel backdrop, welcome board, photo frame"),
            ("Balloons", "Pastel balloon garland, pump, glue dots"),
            ("Flowers", "Seasonal flowers, small vases"),
            ("Tables", "Dessert table cloth, cake stand, tableware"),
            ("Lighting", "Warm fairy lights and LED candles")
        ],
        "menu": ["Welcome drinks: fruit punch", "Snacks: dhokla, sandwiches, cutlets", "Main: paneer curry, veg pulao, naan", "Sides: salad, raita", "Dessert: cupcakes, rasmalai"]
    }
}

def connect_db():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    return con

def init_db():
    with connect_db() as con:
        con.execute("""
        CREATE TABLE IF NOT EXISTS plans (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            event_name TEXT NOT NULL,
            event_type TEXT NOT NULL,
            guests INTEGER NOT NULL,
            budget REAL NOT NULL,
            city TEXT NOT NULL,
            food_preference TEXT NOT NULL,
            created_at TEXT NOT NULL,
            allocation_json TEXT NOT NULL
        )
        """)

def build_plan(data):
    event_type = data.get("event_type", "Birthday Party")
    if event_type not in EVENTS:
        event_type = "Birthday Party"
    budget = max(0, float(data.get("budget", 100000) or 0))
    guests = max(1, min(100000, int(float(data.get("guests", 100) or 100))))
    shares = EVENTS[event_type]["shares"]
    allocations = []
    remaining = round(budget, 2)
    items = list(shares.items())
    for index, (name, pct) in enumerate(items):
        amount = round(budget * pct, 2)
        if index == len(items) - 1:
            amount = round(remaining, 2)
        remaining = round(remaining - amount, 2)
        allocations.append({"name": name, "percent": round(pct * 100, 1), "amount": amount})
    planned = round(sum(x["amount"] for x in allocations), 2)
    return {
        "event_type": event_type, "budget": budget, "guests": guests,
        "planned": planned, "remaining": round(budget - planned, 2),
        "per_guest": round(budget / guests, 2),
        "allocations": allocations,
        "materials": EVENTS[event_type]["materials"],
        "menu": EVENTS[event_type]["menu"],
        "food_preference": data.get("food_preference", "Vegetarian")
    }

@app.route("/")
def home():
    return render_template("index.html", event_types=list(EVENTS.keys()))

@app.route("/api/calculate", methods=["POST"])
def calculate():
    data = request.get_json(silent=True) or request.form.to_dict()
    plan = build_plan(data)
    # Save each calculation to SQLite so the user can demonstrate where data is stored.
    with connect_db() as con:
        cur = con.execute(
            """INSERT INTO plans (event_name, event_type, guests, budget, city, food_preference, created_at, allocation_json)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (data.get("event_name", "My event")[:100], plan["event_type"], plan["guests"],
             plan["budget"], data.get("city", "Mumbai")[:100],
             plan["food_preference"][:50], datetime.now().isoformat(timespec="seconds"),
             json.dumps(plan["allocations"], ensure_ascii=False))
        )
        plan["saved_id"] = cur.lastrowid
    return jsonify(plan)

@app.route("/api/history")
def history():
    with connect_db() as con:
        rows = con.execute("SELECT id,event_name,event_type,guests,budget,city,food_preference,created_at FROM plans ORDER BY id DESC LIMIT 20").fetchall()
    return jsonify([dict(row) for row in rows])

@app.route("/api/plan/<int:plan_id>")
def plan_detail(plan_id):
    with connect_db() as con:
        row = con.execute("SELECT * FROM plans WHERE id=?", (plan_id,)).fetchone()
    if not row:
        return jsonify({"error": "Plan not found"}), 404
    result = dict(row)
    result["allocation_json"] = json.loads(result["allocation_json"])
    return jsonify(result)

if __name__ == "__main__":
    init_db()
    app.run(host="127.0.0.1", port=5000, debug=False)
