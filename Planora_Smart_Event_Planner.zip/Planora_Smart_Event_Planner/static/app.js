const money = n => new Intl.NumberFormat('en-IN',{style:'currency',currency:'INR',maximumFractionDigits:2}).format(Number(n)||0);
const icons = {'Food & catering':'🍲','Decoration':'🌷','Music & sound':'♫','Photographer':'📸','Video editor':'🎞️','Venue & seating':'⌂','Cake & return gifts':'🎂','Makeup & misc.':'✿','Haldi supplies & misc.':'🌼','Decoration & branding':'✦','Audio / visual':'♫','Printing & misc.':'▤','Gifts & misc.':'🎁','Misc.':'✦'};
const colors=['#b99574','#91a38b','#d49c8a','#a99aba','#d4b56f','#8fa9aa','#c69c7e'];
const form=document.getElementById('planForm');
let currentPlan=null;
form.addEventListener('submit', async e=>{e.preventDefault(); await calculateAndSave();});
document.getElementById('resetBtn').addEventListener('click',()=>{document.getElementById('event_name').value='My special event';document.getElementById('event_type').value='Birthday Party';document.getElementById('budget').value=100000;document.getElementById('guests').value=100;document.getElementById('city').value='Mumbai';document.getElementById('food_preference').selectedIndex=0;calculateAndSave();});
document.getElementById('refreshHistory').addEventListener('click',loadHistory);
function payload(){return {event_name:document.getElementById('event_name').value||'My event',event_type:document.getElementById('event_type').value,budget:Math.max(0,Number(document.getElementById('budget').value)||0),guests:Math.max(1,Number(document.getElementById('guests').value)||1),city:document.getElementById('city').value,food_preference:document.getElementById('food_preference').value};}
async function calculateAndSave(){
 const msg=document.getElementById('message');msg.classList.remove('show');
 try{
  const res=await fetch('/api/calculate',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload())});
  if(!res.ok)throw new Error('Server could not calculate this plan.');
  currentPlan=await res.json();renderPlan(currentPlan);
  msg.textContent=`Plan #${currentPlan.saved_id} calculated and saved to database/planora.db`;msg.classList.add('show');
  await loadHistory();
 }catch(err){msg.textContent='Could not reach the local server. Please run run.bat (Windows) or run.sh (Mac/Linux), then open http://127.0.0.1:5000.';msg.classList.add('show');}
}
function renderPlan(p){
 document.getElementById('totalMetric').textContent=money(p.budget);
 document.getElementById('plannedMetric').textContent=money(p.planned);
 document.getElementById('leftMetric').textContent=money(p.remaining);
 document.getElementById('guestMetric').textContent=money(p.per_guest);
 document.getElementById('allocationTotal').textContent=money(p.planned);
 document.getElementById('menuEvent').textContent=p.event_type;
 const list=document.getElementById('allocationList');
 list.innerHTML=p.allocations.map((a,i)=>`<div class="allocation-item"><div class="allocation-meta"><div class="allocation-label"><span class="emoji">${icons[a.name]||'✦'}</span><span>${esc(a.name)}</span></div><div class="allocation-amount">${money(a.amount)}<small>${a.percent}% of budget</small></div></div><div class="track"><div class="fill" style="width:${p.budget?Math.min(100,a.amount/p.budget*100):0}%;background:${colors[i%colors.length]}"></div></div></div>`).join('');
 document.getElementById('materialList').innerHTML=p.materials.map((m,i)=>`<div class="material-item"><div class="material-check">✓</div><div><b>${esc(m[0])}</b><p>${esc(m[1])}</p></div></div>`).join('');
 let menu=p.menu.slice();
 if(p.food_preference==='Veg + Non-veg')menu=menu.map(s=>s.includes('Starters:')?'Starters: paneer tikka, chicken tikka':s.includes('Main:')?'Main: paneer curry, chicken curry, seasonal veg':s);
 if(p.food_preference==='Snacks & desserts')menu=['Welcome drinks: lemonade / fruit punch','Snacks: mini sandwiches, samosa, dhokla','Finger food: paneer bites, fries, pasta cups','Dessert: brownies, cupcakes, gulab jamun'];
 document.getElementById('menuList').innerHTML=menu.map((s,i)=>{let parts=s.split(':');return `<div class="menu-item"><span class="menu-dot"></span><div><b>${esc(parts[0]||'Menu')}</b><span>${esc(parts.slice(1).join(':').trim())}</span></div></div>`}).join('');
 const food=p.allocations.find(a=>a.name==='Food & catering');document.getElementById('foodBudget').textContent=money(food?food.amount:0);
}
function esc(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
async function loadHistory(){
 const target=document.getElementById('historyList');
 try{
  const res=await fetch('/api/history');const rows=await res.json();
  if(!rows.length){target.innerHTML='<p class="empty">No saved plans yet. Calculate your first event plan above.</p>';return;}
  target.innerHTML=rows.map(r=>`<div class="history-row"><div><b>${esc(r.event_name)}</b><small>${esc(r.created_at)}</small></div><div class="hist-type"><b>${esc(r.event_type)}</b><small>${r.guests} guests · ${esc(r.city)}</small></div><div class="hist-money">${money(r.budget)}</div><button onclick="viewPlan(${r.id})">View plan</button></div>`).join('');
 }catch(e){target.innerHTML='<p class="empty">Start the local server to load saved plans.</p>';}
}
async function viewPlan(id){
 try{const r=await fetch('/api/plan/'+id);const p=await r.json();if(!r.ok)throw new Error();document.getElementById('event_name').value=p.event_name;document.getElementById('event_type').value=p.event_type;document.getElementById('budget').value=p.budget;document.getElementById('guests').value=p.guests;document.getElementById('city').value=p.city;document.getElementById('food_preference').value=p.food_preference;await calculateAndSave();document.getElementById('budget').scrollIntoView({behavior:'smooth',block:'center'});}catch(e){alert('Could not load that plan.');}
}
document.addEventListener('DOMContentLoaded',()=>{calculateAndSave();loadHistory();});
