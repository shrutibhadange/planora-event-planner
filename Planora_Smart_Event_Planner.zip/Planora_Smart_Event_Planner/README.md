# Planora — Smart Event Planning & Budget Management

## Files and folders
- `app.py` — Python Flask backend, calculation rules, API and database saving.
- `templates/index.html` — website page.
- `static/style.css` — warm cream, light brown, sage and blush theme.
- `static/app.js` — interactive UI, fetch requests, saved history.
- `database/` — SQLite database folder. `planora.db` is created automatically on first run.
- `run.bat` — Windows one-click runner.
- `run.sh` — Mac/Linux runner.
- `requirements.txt` — Python dependency list.

## Run on Windows
1. Install Python 3 from https://www.python.org/downloads/ if it is not installed. During installation, tick **Add Python to PATH**.
2. Extract this ZIP to a normal folder.
3. Double-click `run.bat`. Allow it to install Flask the first time.
4. When the terminal says the server is running, open Chrome and visit `http://127.0.0.1:5000`.
5. Keep the terminal window open while presenting the website. Close it to stop the server.

## Run on Mac/Linux
Open Terminal in this folder and run:
`chmod +x run.sh && ./run.sh`
Then visit `http://127.0.0.1:5000`.

## Where is data stored?
Each time Calculate is clicked, the backend writes a row to **`database/planora.db`** (SQLite). This is a local database file on the same computer. The Saved Plans section loads the most recent 20 entries from it. The `/api/history` endpoint returns the history as JSON.

## Calculation
Budget allocation percentages are configured per event type in `EVENTS` in `app.py`. Percentages for each type total 100%. Amounts are calculated from any non-negative budget amount, rounded to two decimal places, with rounding remainder assigned to the last category so the total matches the entered budget. Guests are used to calculate budget per guest.

Event templates currently include Birthday Party, Wedding, Haldi Ceremony, Engagement, Corporate Event, and Baby Shower. The page updates decoration/material suggestions and sample menu according to the event type. These are planning examples, not live vendor quotes.

## Public link / showing it on another phone
`http://127.0.0.1:5000` works on the computer running the app. It is not a public Google-searchable URL. To show it on another phone on the same Wi-Fi, use the computer's local network IP and configure the app to listen on the network; only do this on a trusted network. For a public URL, deploy the project to a hosting service (for example Render) and configure persistent storage for SQLite, or move to a managed database. A public deployment needs an account and setup; no public URL can be created just by typing a PIN into Google. Do not expose a development server directly to the public internet.

## Demo notes
- No login or PIN is implemented. Avoid storing personal or sensitive data in this demo.
- Confirm real prices, availability, food allergies and vendor terms with vendors.
