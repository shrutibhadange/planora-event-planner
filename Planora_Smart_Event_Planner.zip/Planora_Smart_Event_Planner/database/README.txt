SQLite database folder.
The actual database file database/planora.db is created automatically the first time app.py starts.
Each calculation is saved in the plans table. You can inspect it with a SQLite viewer or the included /api/history endpoint.
